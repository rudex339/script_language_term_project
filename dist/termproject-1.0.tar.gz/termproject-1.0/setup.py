
from distutils.core import setup
setup(name = "termproject",
    version = "1.0",
    py_modules = ['search_window','telegrambot','noti','main_data','find_window']
)
